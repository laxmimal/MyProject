package pack;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class Main {

	public static void main(String args[])
	{
		SessionFactory sessions=new Configuration().configure().buildSessionFactory();
		Session session=sessions.openSession();

 
		Emp obj=(Emp)session.get(Emp.class,34);
		System.out.println(obj.getName()); 

 	/*Query query = session.createQuery("from Emp as e where  id=? and  name=?");
			 query.setInteger(0,Integer.valueOf(20));
			 query.setString(1, "abc");
			 query.setCacheable(true);

			 List<Emp> employees =(List<Emp>)query.list();

			 for (Emp e:employees)
			 {


				System.out.println(e.getSal());
			 } */
		session.close();

		 
       session=sessions.openSession();
	 	Emp obj2=(Emp)session.get(Emp.class,34);
		 System.out.println(obj2.getName()); 
		 
		  /* query = session.createQuery("from Emp as e where  id=? and  name=?");
		 query.setInteger(0,Integer.valueOf(20));
		 query.setString(1, "abc");
		 query.setCacheable(true);
		  employees =(List<Emp>)query.list();

		 for (Emp e:employees)
		 {


			System.out.println(e.getSal());
		 } */
		session.close();


	} 


}

