package pack_p7;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;



public class Main {
//a student can enroll in any number of courses and the course can have any number of students. 

	public static void main(String[] args) {

SessionFactory sessions = new AnnotationConfiguration().configure().buildSessionFactory();
        
        Session session = sessions.openSession();
        Transaction transaction1 = null;
        
		try {
			transaction1 = session.beginTransaction();
			
			Student student1=new Student();
			Student student2=new Student();
			
			student1.setStudentName("Shriya");
			student2.setStudentName("preethi");
			
			Course course1=new Course();
			Course course2=new Course();
			
			course1.setCourseName("EEE");
			course2.setCourseName("IT");
			course1.setCourseDesc("Electronics");
			course2.setCourseDesc("Information Tech.");
			
			Set<Course> courses = new HashSet<Course>();
			courses.add(course1);
			courses.add(course2);
			student1.setCourses(courses);
			session.save(student1);
		
		
			student2.setCourses(courses);
			session.save(student2); 
     
			Set s1=student1.getCourses();
			 for (Iterator iterator = 
                s1.iterator(); iterator.hasNext();){
 Course C = (Course) iterator.next(); 
 System.out.println("Course Name: " + C.getCourseName()); 
                     
			 }
			
			transaction1.commit();
						
        
		} catch (HibernateException e) {
			transaction1.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}
}
